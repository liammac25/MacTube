import supabase from './db-client.js';

const QUALITIES = [
  { id: '360p', label: '360p', format: 'MP4', size: '28 MB', tier: 'free', height: 360 },
  { id: '480p', label: '480p', format: 'MP4', size: '48 MB', tier: 'free', height: 480 },
  { id: '720p', label: '720p HD', format: 'MP4', size: '92 MB', tier: 'free', height: 720 },
  { id: '1080p', label: '1080p Full HD', format: 'MP4', size: '210 MB', tier: 'premium', height: 1080 },
  { id: '4K', label: '4K Ultra HD', format: 'MP4', size: '680 MB', tier: 'premium', height: 2160 },
  { id: 'mp3', label: 'MP3 Audio', format: 'MP3', size: '9 MB', tier: 'premium', height: 0 },
];

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function isValidHttpUrl(value) {
  if (!value || typeof value !== 'string') return false;
  try {
    const parsed = new URL(value.trim());
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function parseVideo(urlStr) {
  const u = new URL(urlStr);
  const host = u.hostname.replace(/^www\./, '').toLowerCase();
  if (host === 'youtu.be') {
    return { provider: 'YouTube', video_id: u.pathname.split('/').filter(Boolean)[0] || null };
  }
  if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com' || host === 'youtube-nocookie.com') {
    let id = u.searchParams.get('v');
    if (!id && u.pathname.startsWith('/shorts/')) id = u.pathname.split('/')[2];
    if (!id && u.pathname.startsWith('/embed/')) id = u.pathname.split('/')[2];
    if (!id && u.pathname.startsWith('/live/')) id = u.pathname.split('/')[2];
    return { provider: 'YouTube', video_id: id || null };
  }
  if (host === 'vimeo.com' || host === 'player.vimeo.com') {
    const parts = u.pathname.split('/').filter(Boolean);
    const id = parts.find((p) => /^\d+$/.test(p)) || parts[0] || null;
    return { provider: 'Vimeo', video_id: id };
  }
  return { provider: host, video_id: null };
}

async function fetchMeta(url, parsed) {
  const fallbackThumb =
    parsed.provider === 'YouTube' && parsed.video_id
      ? `https://i.ytimg.com/vi/${parsed.video_id}/hqdefault.jpg`
      : null;

  try {
    if (parsed.provider === 'YouTube') {
      const r = await fetch(
        `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`,
        { signal: AbortSignal.timeout(8000) }
      );
      if (r.ok) {
        const j = await r.json();
        return {
          title: j.title || 'YouTube video',
          author: j.author_name || 'YouTube',
          thumbnail: j.thumbnail_url || fallbackThumb,
          provider: 'YouTube',
        };
      }
    }
    if (parsed.provider === 'Vimeo') {
      const r = await fetch(`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`, {
        signal: AbortSignal.timeout(8000),
      });
      if (r.ok) {
        const j = await r.json();
        return {
          title: j.title || 'Vimeo video',
          author: j.author_name || 'Vimeo',
          thumbnail: j.thumbnail_url || null,
          provider: 'Vimeo',
        };
      }
    }
  } catch {
    // Use fallback metadata below
  }

  const host = new URL(url).hostname.replace(/^www\./, '');
  return {
    title: parsed.video_id ? `Video ${parsed.video_id}` : `Media from ${host}`,
    author: host,
    thumbnail: fallbackThumb,
    provider: parsed.provider,
  };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id } = req.query || {};
      if (id) {
        const { data, error } = await supabase
          .from('conversions')
          .select('*')
          .eq('id', id)
          .single();
        if (error) throw error;
        return res.status(200).json({ conversion: data, qualities: QUALITIES });
      }
      const { data, error } = await supabase
        .from('conversions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(80);
      if (error) throw error;
      return res.status(200).json({ conversions: data, qualities: QUALITIES });
    }

    if (req.method === 'POST') {
      const { url } = req.body || {};
      if (!url || typeof url !== 'string' || !url.trim()) {
        return res.status(400).json({ error: 'Please enter a video URL.' });
      }
      if (!isValidHttpUrl(url)) {
        return res.status(400).json({ error: 'That does not look like a valid URL.' });
      }

      const trimmed = url.trim();
      const parsed = parseVideo(trimmed);
      const meta = await fetchMeta(trimmed, parsed);

      const { data, error } = await supabase
        .from('conversions')
        .insert({
          url: trimmed,
          title: meta.title,
          thumbnail: meta.thumbnail,
          author: meta.author,
          provider: meta.provider,
          video_id: parsed.video_id,
          status: 'ready',
          is_favorite: false,
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json({ conversion: data, qualities: QUALITIES });
    }

    if (req.method === 'PUT') {
      const { id, is_favorite, title } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Missing conversion id.' });
      const patch = {};
      if (typeof is_favorite === 'boolean') patch.is_favorite = is_favorite;
      if (typeof title === 'string' && title.trim()) patch.title = title.trim();
      if (Object.keys(patch).length === 0) {
        return res.status(400).json({ error: 'Nothing to update.' });
      }
      const { data, error } = await supabase
        .from('conversions')
        .update(patch)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json({ conversion: data });
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Missing conversion id.' });
      const { error } = await supabase.from('conversions').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('convert API error:', err);
    return res.status(500).json({ error: err.message || 'Conversion failed. Please try again.' });
  }
}
