import supabase from './db-client.js';

const PREMIUM = new Set(['1080p', '4K', 'mp3', '2160p']);

const QUALITY_FORMAT = {
  '360p': 'MP4',
  '480p': 'MP4',
  '720p': 'MP4',
  '1080p': 'MP4',
  '4K': 'MP4',
  mp3: 'MP3',
};

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
}

function safeName(value) {
  return String(value || 'video')
    .replace(/[^\w\d]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 72) || 'video';
}

function ticketBody(row, quality) {
  return [
    'MacTube Conversion',
    '==================',
    `Title     : ${row.title}`,
    `Author    : ${row.author || 'Unknown'}`,
    `Provider  : ${row.provider || 'Web'}`,
    `Quality   : ${quality}`,
    `Format    : ${QUALITY_FORMAT[quality] || 'MP4'}`,
    `Source    : ${row.url}`,
    `Created   : ${row.created_at}`,
    '',
    'This file is your MacTube free-tier download package.',
    'Open MacTube to convert another link or upgrade for HD & MP3.',
    '',
  ].join('\n');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const id = req.query?.id;
      const quality = req.query?.quality;

      if (!id || !quality) {
        const { data, error } = await supabase
          .from('downloads')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(80);
        if (error) throw error;
        return res.status(200).json(data);
      }

      if (PREMIUM.has(String(quality))) {
        return res.status(403).json({
          error: 'Upgrade to MacTube Premium for HD downloads',
          premium: true,
        });
      }

      const { data: row, error } = await supabase
        .from('conversions')
        .select('*')
        .eq('id', id)
        .single();
      if (error || !row) {
        return res.status(404).json({ error: 'Conversion not found.' });
      }

      const format = QUALITY_FORMAT[quality] || 'MP4';
      const filename = `${safeName(row.title)}-${quality}.txt`;

      await supabase.from('downloads').insert({
        conversion_id: row.id,
        quality,
        format,
        filename,
        title: row.title,
      });

      const body = ticketBody(row, quality);
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      return res.status(200).send(body);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Missing download id.' });
      const { error } = await supabase.from('downloads').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('download API error:', err);
    return res.status(500).json({ error: err.message || 'Download failed.' });
  }
}
