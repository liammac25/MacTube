import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('premium_signups')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { email, name, plan } = req.body || {};
      if (!isEmail(email)) {
        return res.status(400).json({ error: 'Please enter a valid email address.' });
      }
      const { data, error } = await supabase
        .from('premium_signups')
        .insert({
          email: String(email).trim().toLowerCase(),
          name: (name && String(name).trim()) || 'MacTube listener',
          plan: plan || 'premium-monthly',
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Missing signup id.' });
      const { error } = await supabase.from('premium_signups').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('premium API error:', err);
    return res.status(500).json({ error: err.message || 'Could not save Premium request.' });
  }
}
