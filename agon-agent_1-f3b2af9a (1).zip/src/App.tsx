import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Loader2, Maximize2, Minus, X, PanelLeft } from 'lucide-react'
import MenuBar from './components/MenuBar'
import AdBanner from './components/AdBanner'
import Dock from './components/Dock'
import ConvertForm from './components/ConvertForm'
import Results from './components/Results'
import Sidebar from './components/Sidebar'
import PremiumModal from './components/PremiumModal'
import HowItWorks from './components/HowItWorks'
import CasualFaq from './components/CasualFaq'
import type { Conversion, DownloadLog, Quality } from './types'

function isValidHttpUrl(value: string) {
  try {
    const parsed = new URL(value.trim())
    return parsed.protocol === 'http:' || parsed.protocol === 'https:'
  } catch {
    return false
  }
}

export default function App() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [boot, setBoot] = useState(true)
  const [error, setError] = useState('')
  const [current, setCurrent] = useState<Conversion | null>(null)
  const [conversions, setConversions] = useState<Conversion[]>([])
  const [qualities, setQualities] = useState<Quality[]>([])
  const [downloads, setDownloads] = useState<DownloadLog[]>([])
  const [modalOpen, setModalOpen] = useState(false)
  const [modalQuality, setModalQuality] = useState<Quality | null>(null)
  const [downloadingId, setDownloadingId] = useState<string | null>(null)
  const [windowState, setWindowState] = useState<'normal' | 'minimized' | 'fullscreen'>('normal')
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const fetchHistory = useCallback(async () => {
    try {
      const res = await fetch('/api/convert')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Could not load history')
      setConversions(data.conversions || [])
      if (data.qualities) setQualities(data.qualities)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load history')
    } finally {
      setBoot(false)
    }
  }, [])

  const fetchDownloads = useCallback(async () => {
    try {
      const res = await fetch('/api/download')
      const data = await res.json()
      if (res.ok && Array.isArray(data)) setDownloads(data)
    } catch {
      // history of downloads is secondary
    }
  }, [])

  useEffect(() => {
    fetchHistory()
    fetchDownloads()
  }, [fetchHistory, fetchDownloads])

  const convert = async () => {
    setError('')
    const trimmed = url.trim()
    if (!trimmed) {
      setError('Please enter a video URL.')
      return
    }
    if (!isValidHttpUrl(trimmed)) {
      setError('That does not look like a valid URL.')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/convert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Conversion failed. Please try another URL.')
      setCurrent(data.conversion)
      if (data.qualities) setQualities(data.qualities)
      await fetchHistory()
    } catch (err) {
      setCurrent(null)
      setError(err instanceof Error ? err.message : 'Conversion failed. Please try another URL.')
    } finally {
      setLoading(false)
    }
  }

  const toggleFavorite = async (item: Conversion) => {
    try {
      const res = await fetch('/api/convert', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: item.id, is_favorite: !item.is_favorite }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Could not update')
      setConversions((prev) => prev.map((c) => (c.id === item.id ? data.conversion : c)))
      if (current?.id === item.id) setCurrent(data.conversion)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update favorite')
    }
  }

  const removeConversion = async (item: Conversion) => {
    try {
      const res = await fetch('/api/convert', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: item.id }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Could not delete')
      setConversions((prev) => prev.filter((c) => c.id !== item.id))
      if (current?.id === item.id) setCurrent(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete conversion')
    }
  }

  const downloadFree = async (q: Quality) => {
    if (!current) return
    setDownloadingId(q.id)
    setError('')
    try {
      const res = await fetch(`/api/download?id=${current.id}&quality=${encodeURIComponent(q.id)}`)
      if (res.status === 403) {
        setModalQuality(q)
        setModalOpen(true)
        return
      }
      if (!res.ok) {
        const payload = await res.json().catch(() => ({}))
        throw new Error(payload.error || 'Download failed. Please try again.')
      }
      const blob = await res.blob()
      const cd = res.headers.get('Content-Disposition') || ''
      const match = cd.match(/filename="([^"]+)"/)
      const filename = match?.[1] || `${current.title}-${q.id}.txt`
      const href = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = href
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(href)
      await fetchDownloads()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Download failed. Please try again.')
    } finally {
      setDownloadingId(null)
    }
  }

  const openPremium = (q: Quality) => {
    setModalQuality(q)
    setModalOpen(true)
  }

  if (windowState === 'minimized') {
    return (
      <div className="min-h-screen">
        <MenuBar />
        <Dock onOpen={() => setWindowState('normal')} minimized />
      </div>
    )
  }

  const fullscreen = windowState === 'fullscreen'

  return (
    <div className="min-h-screen pb-28 pt-8">
      <MenuBar />
      <AdBanner variant="leaderboard" />

      <main className={`px-3 py-5 sm:px-6 ${fullscreen ? 'mx-auto max-w-none' : ''}`}>
        <motion.section
          layout
          className={`glass-window mx-auto overflow-hidden rounded-xl border border-white/10 ${
            fullscreen ? 'min-h-[calc(100vh-9rem)] max-w-none' : 'max-w-6xl'
          }`}
        >
          <div className="flex h-12 items-center border-b border-white/8 px-3">
            <div className="traffic flex items-center gap-2 pr-3">
              <button
                type="button"
                onClick={() => {
                  setCurrent(null)
                  setUrl('')
                  setError('')
                }}
                className="flex h-3 w-3 items-center justify-center rounded-full bg-[#ff5f57]"
                aria-label="Close"
              >
                <X className="glyph h-2 w-2 text-[#4d0000] opacity-0" />
              </button>
              <button
                type="button"
                onClick={() => setWindowState('minimized')}
                className="flex h-3 w-3 items-center justify-center rounded-full bg-[#febc2e]"
                aria-label="Minimize"
              >
                <Minus className="glyph h-2 w-2 text-[#5a3b00] opacity-0" />
              </button>
              <button
                type="button"
                onClick={() => setWindowState(fullscreen ? 'normal' : 'fullscreen')}
                className="flex h-3 w-3 items-center justify-center rounded-full bg-[#28c840]"
                aria-label="Zoom"
              >
                <Maximize2 className="glyph h-2 w-2 text-[#0b3d12] opacity-0" />
              </button>
            </div>
            <p className="flex-1 text-center text-[13px] font-medium text-white/70">MacTube</p>
            <button
              type="button"
              onClick={() => setSidebarOpen((v) => !v)}
              className="rounded-md p-1.5 text-white/50 hover:bg-white/10 lg:hidden"
              aria-label="Toggle sidebar"
            >
              <PanelLeft className="h-4 w-4" />
            </button>
          </div>

          <div className="flex min-h-[560px] flex-col lg:flex-row">
            <div className={`${sidebarOpen ? 'block' : 'hidden'} lg:block`}>
              <Sidebar
                conversions={conversions}
                downloads={downloads}
                selectedId={current?.id ?? null}
                onSelect={(item) => {
                  setCurrent(item)
                  setUrl(item.url)
                  setError('')
                }}
                onFavorite={toggleFavorite}
                onDelete={removeConversion}
              />
            </div>

            <div className="mac-scroll relative flex-1 overflow-y-auto px-4 py-8 sm:px-8">
              {boot ? (
                <div className="flex h-72 flex-col items-center justify-center gap-3 text-white/50">
                  <Loader2 className="h-8 w-8 animate-spin text-[#0a84ff]" />
                  <p className="text-sm">Getting things ready…</p>
                </div>
              ) : (
                <>
                  <ConvertForm
                    url={url}
                    setUrl={(v) => {
                      setUrl(v)
                      setError('')
                    }}
                    loading={loading}
                    error={error}
                    onConvert={convert}
                    showSamples={!current}
                  />
                  {loading && (
                    <div className="mt-10 flex flex-col items-center gap-3 text-white/60">
                      <span className="relative flex h-12 w-12 items-center justify-center">
                        <span className="absolute inset-0 rounded-full border-2 border-white/10" />
                        <span className="absolute inset-0 animate-spin rounded-full border-2 border-transparent border-t-[#0a84ff]" />
                      </span>
                      <p className="text-sm">Looking up your video… this only takes a moment.</p>
                    </div>
                  )}
                  {!loading && current && (
                    <Results
                      conversion={current}
                      qualities={qualities}
                      downloadingId={downloadingId}
                      onFreeDownload={downloadFree}
                      onPremium={openPremium}
                    />
                  )}
                  {!loading && !current && (
                    <>
                      <HowItWorks />
                      <CasualFaq />
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </motion.section>
      </main>

      <p className="mx-auto max-w-xl px-6 pb-2 text-center text-[12px] leading-relaxed text-white/35">
        MacTube is a simple saver for everyday videos — no account, no extra software. Free 720p for everyone.
      </p>

      <Dock onOpen={() => setWindowState('normal')} minimized={false} />

      <AnimatePresence>
        {modalOpen && (
          <PremiumModal quality={modalQuality} onClose={() => setModalOpen(false)} />
        )}
      </AnimatePresence>
    </div>
  )
}
