export type Quality = {
  id: string;
  label: string;
  format: string;
  size: string;
  tier: 'free' | 'premium';
  height: number;
};

export type Conversion = {
  id: number;
  url: string;
  title: string;
  thumbnail: string | null;
  author: string | null;
  provider: string | null;
  video_id: string | null;
  status: string;
  is_favorite: boolean;
  created_at: string;
};

export type DownloadLog = {
  id: number;
  conversion_id: number;
  quality: string;
  format: string;
  filename: string;
  title: string;
  created_at: string;
};
