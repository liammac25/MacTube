import { Clock, Star, Trash2, History } from 'lucide-react'
import type { Conversion, DownloadLog } from '../types'
import AdBanner from './AdBanner'

type Props = {
  conversions: Conversion[]
  downloads: DownloadLog[]
  selectedId: number | null
  onSelect: (item: Conversion) => void
  onFavorite: (item: Conversion) => void
  onDelete: (item: Conversion) => void
}

export default function Sidebar({ conversions, downloads, selectedId, onSelect, onFavorite, onDelete }: Props) {
  return (
    <aside className="mac-scroll flex w-full shrink-0 flex-col border-white/8 bg-white/[0.03] lg:w-[300px] lg:border-r lg:overflow-y-auto">
      <div className="px-4 pb-2 pt-4">
        <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/40">
          <History className="h-3.5 w-3.5" /> Recents
        </div>
      </div>
      <div className="flex-1 px-2 pb-3">
        {conversions.length === 0 ? (
          <p className="px-3 py-6 text-center text-xs text-white/35">Nothing here yet. Paste a link and tap Convert.</p>
        ) : (
          <ul className="space-y-1">
            {conversions.map((item) => {
              const active = selectedId === item.id
              return (
                <li key={item.id}>
                  <div
                    className={`group flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 ${
                      active ? 'bg-[#0a84ff]/80' : 'hover:bg-white/8'
                    }`}
                    onClick={() => onSelect(item)}
                  >
                    <img
                      src={item.thumbnail || '/mactube-icon.png'}
                      alt=""
                      className="h-9 w-12 shrink-0 rounded object-cover bg-black/40"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-medium leading-tight">{item.title}</p>
                      <p className={`truncate text-[10px] ${active ? 'text-white/80' : 'text-white/40'}`}>
                        {item.provider || 'Web'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        onFavorite(item)
                      }}
                      className="rounded p-1 opacity-70 hover:opacity-100"
                      aria-label="Favorite"
                    >
                      <Star
                        className={`h-3.5 w-3.5 ${
                          item.is_favorite ? 'fill-amber-300 text-amber-300' : 'text-white/40'
                        }`}
                      />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation()
                        onDelete(item)
                      }}
                      className="rounded p-1 text-white/30 opacity-0 hover:text-red-400 group-hover:opacity-100"
                      aria-label="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>

      {downloads.length > 0 && (
        <div className="border-t border-white/8 px-4 py-3">
          <div className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/40">
            <Clock className="h-3.5 w-3.5" /> Downloads
          </div>
          <ul className="space-y-1">
            {downloads.slice(0, 4).map((d) => (
              <li key={d.id} className="truncate text-[11px] text-white/50">
                {d.quality} · {d.title}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-auto hidden border-t border-white/8 p-3 lg:block">
        <AdBanner variant="rectangle" />
      </div>
    </aside>
  )
}
