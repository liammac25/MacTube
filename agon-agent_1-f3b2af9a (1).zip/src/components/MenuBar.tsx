import { useEffect, useState } from 'react'
import { Wifi, BatteryFull, Search } from 'lucide-react'

export default function MenuBar() {
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const time = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
  const date = now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })

  return (
    <header className="fixed inset-x-0 top-0 z-40 flex h-8 items-center justify-between bg-black/35 px-3 text-[13px] text-white/90 backdrop-blur-2xl">
      <div className="flex items-center gap-4">
        <span className="font-semibold tracking-tight">MacTube</span>
        <nav className="hidden items-center gap-4 text-white/80 sm:flex">
          <span>File</span>
          <span>Edit</span>
          <span>View</span>
          <span>Window</span>
          <span>Help</span>
        </nav>
      </div>
      <div className="flex items-center gap-3 text-white/85">
        <Search className="hidden h-3.5 w-3.5 sm:block" strokeWidth={2.2} />
        <Wifi className="h-3.5 w-3.5" strokeWidth={2.2} />
        <BatteryFull className="h-3.5 w-3.5" strokeWidth={2.2} />
        <span className="tabular-nums">
          {date} {time}
        </span>
      </div>
    </header>
  )
}
