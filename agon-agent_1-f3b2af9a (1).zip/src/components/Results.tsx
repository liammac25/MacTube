import { Crown, Download, Loader2, Lock, Music, Film } from 'lucide-react'
import type { Conversion, Quality } from '../types'

type Props = {
  conversion: Conversion
  qualities: Quality[]
  downloadingId: string | null
  onFreeDownload: (q: Quality) => void
  onPremium: (q: Quality) => void
}

export default function Results({ conversion, qualities, downloadingId, onFreeDownload, onPremium }: Props) {
  const free = qualities.filter((q) => q.tier === 'free')
  const premium = qualities.filter((q) => q.tier === 'premium')

  return (
    <div className="mx-auto mt-8 w-full max-w-2xl">
      <div className="glass-card overflow-hidden rounded-2xl">
        <div className="flex flex-col gap-4 p-4 sm:flex-row">
          <img
            src={conversion.thumbnail || '/mactube-icon.png'}
            alt=""
            className="h-32 w-full rounded-xl object-cover sm:h-28 sm:w-44"
          />
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#0a84ff]">
              {conversion.provider || 'Ready'}
            </p>
            <h2 className="mt-1 text-lg font-semibold leading-snug">{conversion.title}</h2>
            <p className="mt-1 text-sm text-white/50">{conversion.author || 'Unknown creator'}</p>
            <p className="mt-2 truncate text-[11px] text-white/30">{conversion.url}</p>
          </div>
        </div>
      </div>

      <section className="mt-5">
        <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-white/40">
          <Film className="h-3.5 w-3.5" /> Free downloads
        </h3>
        <div className="space-y-2">
          {free.map((q) => {
            const busy = downloadingId === q.id
            return (
              <button
                key={q.id}
                type="button"
                onClick={() => onFreeDownload(q)}
                disabled={!!downloadingId}
                className="glass-card flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition hover:bg-white/10 disabled:opacity-60"
              >
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0a84ff]/20 text-[#64b5ff]">
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                </span>
                <span className="flex-1">
                  <span className="block text-sm font-medium">{q.label}</span>
                  <span className="block text-[11px] text-white/40">
                    {q.format} · ~{q.size}
                  </span>
                </span>
                <span className="text-xs font-medium text-[#64b5ff]">{busy ? 'Saving…' : 'Download'}</span>
              </button>
            )
          })}
        </div>
      </section>

      <section className="mt-6">
        <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-amber-200/70">
          <Crown className="h-3.5 w-3.5" /> Premium
        </h3>
        <div className="space-y-2">
          {premium.map((q) => (
            <button
              key={q.id}
              type="button"
              onClick={() => onPremium(q)}
              className="flex w-full items-center gap-3 rounded-xl border border-amber-400/20 bg-amber-400/10 px-3 py-3 text-left backdrop-blur-md transition hover:bg-amber-400/16"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-400/15 text-amber-300">
                {q.id === 'mp3' ? <Music className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
              </span>
              <span className="flex-1">
                <span className="block text-sm font-medium">{q.label}</span>
                <span className="block text-[11px] text-white/40">
                  {q.format} · ~{q.size}
                </span>
              </span>
              <span className="rounded-full bg-gradient-to-r from-amber-300 to-orange-400 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-zinc-900">
                Premium
              </span>
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}
