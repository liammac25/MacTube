import { Folder, Compass, Music2, Trash2 } from 'lucide-react'

type Props = {
  onOpen: () => void
  minimized: boolean
}

export default function Dock({ onOpen, minimized }: Props) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-3 z-40 flex justify-center px-3">
      <div className="pointer-events-auto flex items-end gap-2 rounded-2xl border border-white/20 bg-white/12 px-3 py-2 shadow-2xl backdrop-blur-3xl">
        <DockItem label="Finder">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-sky-300 to-blue-600">
            <Folder className="h-6 w-6 text-white" fill="currentColor" />
          </div>
        </DockItem>
        <button type="button" onClick={onOpen} className="group relative flex flex-col items-center">
          <img
            src="/mactube-icon.png"
            alt="MacTube"
            className="h-12 w-12 rounded-[14px] shadow-lg transition-transform duration-200 group-hover:-translate-y-2"
          />
          <span className={`mt-1 h-1 w-1 rounded-full ${minimized ? 'bg-amber-300' : 'bg-white'}`} />
        </button>
        <DockItem label="Safari">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-b from-white to-sky-400">
            <Compass className="h-6 w-6 text-blue-700" />
          </div>
        </DockItem>
        <DockItem label="Music">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-rose-400 to-pink-700">
            <Music2 className="h-6 w-6 text-white" />
          </div>
        </DockItem>
        <div className="mx-1 h-10 w-px bg-white/20" />
        <DockItem label="Trash">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-b from-zinc-400 to-zinc-600">
            <Trash2 className="h-5 w-5 text-white" />
          </div>
        </DockItem>
      </div>
    </div>
  )
}

function DockItem({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="group relative flex flex-col items-center">
      <div className="transition-transform duration-200 group-hover:-translate-y-2">{children}</div>
      <span className="pointer-events-none absolute -top-8 hidden rounded-md bg-black/80 px-2 py-0.5 text-[10px] text-white group-hover:block">
        {label}
      </span>
    </div>
  )
}
