import { ClipboardPaste, Loader2, Sparkles } from 'lucide-react'
import TryLinks from './TryLinks'

type Props = {
  url: string
  setUrl: (v: string) => void
  loading: boolean
  error: string
  onConvert: () => void
  showSamples?: boolean
}

export default function ConvertForm({ url, setUrl, loading, error, onConvert, showSamples = true }: Props) {
  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText()
      if (text) setUrl(text.trim())
    } catch {
      setUrl(url)
    }
  }

  return (
    <div className="mx-auto w-full max-w-2xl">
      <div className="flex flex-col items-center text-center">
        <img src="/mactube-icon.png" alt="MacTube" className="h-20 w-20 rounded-[22px] shadow-2xl" />
        <h1 className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">MacTube</h1>
        <p className="mt-2 max-w-md text-sm leading-relaxed text-white/55">
          Save any public video in a few taps. Perfect for memes, recipes, workouts, and songs you want offline.
        </p>
      </div>

      <form
        className="mt-6"
        onSubmit={(e) => {
          e.preventDefault()
          onConvert()
        }}
      >
        <div className="glass-card flex flex-col gap-2 rounded-[22px] p-2 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste a video URL…"
              spellCheck={false}
              className="h-12 w-full rounded-2xl border border-transparent bg-white/6 pl-4 pr-12 text-[15px] outline-none placeholder:text-white/30 focus:border-[#0a84ff]/70 focus:bg-white/10"
            />
            <button
              type="button"
              onClick={paste}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-white/45 hover:bg-white/10 hover:text-white"
              aria-label="Paste from clipboard"
            >
              <ClipboardPaste className="h-4 w-4" />
            </button>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-[#0a84ff] px-6 text-sm font-semibold shadow-[0_8px_24px_rgba(10,132,255,0.35)] transition hover:bg-[#0077ed] disabled:opacity-70"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Converting
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Convert
              </>
            )}
          </button>
        </div>
        {error && (
          <p className="mt-3 rounded-xl border border-red-400/25 bg-red-500/15 px-3 py-2 text-left text-sm text-red-100 backdrop-blur-md">
            {error}
          </p>
        )}
      </form>

      {showSamples && !loading && <TryLinks onPick={setUrl} />}
    </div>
  )
}
