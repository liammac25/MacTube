type Props = {
  onPick: (url: string) => void
}

const SAMPLES = [
  { label: 'A classic music video', url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { label: 'A feel-good hit', url: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk' },
  { label: 'A product film', url: 'https://vimeo.com/148751763' },
]

export default function TryLinks({ onPick }: Props) {
  return (
    <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
      <span className="text-[11px] text-white/35">Not sure? Try one:</span>
      {SAMPLES.map((s) => (
        <button
          key={s.url}
          type="button"
          onClick={() => onPick(s.url)}
          className="rounded-full border border-white/12 bg-white/8 px-3 py-1 text-[11px] text-white/70 backdrop-blur-md transition hover:bg-white/14 hover:text-white"
        >
          {s.label}
        </button>
      ))}
    </div>
  )
}
