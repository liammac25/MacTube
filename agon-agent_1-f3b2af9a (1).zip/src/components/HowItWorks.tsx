import { Link2, WandSparkles, Download } from 'lucide-react'

const STEPS = [
  {
    n: '1',
    icon: Link2,
    title: 'Copy a video link',
    body: 'Grab the share URL from YouTube, Vimeo, or anywhere you watch. No apps, no extra tools.',
  },
  {
    n: '2',
    icon: WandSparkles,
    title: 'Paste and Convert',
    body: 'Drop it in the box up top and tap Convert. MacTube finds the video and lines up the sizes for you.',
  },
  {
    n: '3',
    icon: Download,
    title: 'Tap to download',
    body: '360p, 480p, and 720p are free and start right in your browser. HD, 4K, and MP3 are Premium.',
  },
]

export default function HowItWorks() {
  return (
    <section className="mx-auto mt-12 w-full max-w-2xl">
      <p className="text-center text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40">
        Made for everyday saving
      </p>
      <h2 className="mt-1 text-center text-2xl font-semibold tracking-tight">How MacTube works</h2>
      <p className="mx-auto mt-2 max-w-md text-center text-sm leading-relaxed text-white/50">
        Built for casual watching — memes, recipes, workouts, kids’ videos, and that song you keep replaying. Three taps. Done.
      </p>

      <ol className="mt-6 grid gap-3 sm:grid-cols-3">
        {STEPS.map((step) => {
          const Icon = step.icon
          return (
            <li key={step.n} className="glass-card rounded-2xl p-4">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0a84ff]/20 text-[#7ab8ff]">
                  <Icon className="h-4 w-4" />
                </span>
                <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                  Step {step.n}
                </span>
              </div>
              <h3 className="mt-3 text-sm font-semibold">{step.title}</h3>
              <p className="mt-1.5 text-[13px] leading-relaxed text-white/50">{step.body}</p>
            </li>
          )
        })}
      </ol>
    </section>
  )
}
