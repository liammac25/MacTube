import { useState } from 'react'
import { motion } from 'framer-motion'
import { Crown, Sparkles, X, Check, Music, MonitorPlay, Ban } from 'lucide-react'
import type { Quality } from '../types'

type Props = {
  quality: Quality | null
  onClose: () => void
}

export default function PremiumModal({ quality, onClose }: Props) {
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Enter a valid email to continue.')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/premium', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          name: name.trim() || undefined,
          plan: 'premium-monthly',
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Could not start Premium.')
      setDone(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start Premium.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <button type="button" className="absolute inset-0 bg-black/55 backdrop-blur-sm" onClick={onClose} aria-label="Close" />
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="glass-window relative w-full max-w-md overflow-hidden rounded-2xl border border-white/12 shadow-2xl"
      >
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-br from-amber-400/25 via-orange-500/10 to-transparent" />
        <button
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 z-10 rounded-full p-1 text-white/50 hover:bg-white/10 hover:text-white"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="relative px-6 pb-6 pt-8">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-300 to-orange-500 shadow-lg shadow-orange-500/30">
            <Crown className="h-7 w-7 text-zinc-900" />
          </div>
          <h2 className="mt-4 text-center text-xl font-semibold tracking-tight">
            Upgrade to MacTube Premium for HD downloads
          </h2>
          <p className="mt-2 text-center text-sm text-white/55">
            {quality
              ? `${quality.label} (${quality.format}) is included with Premium.`
              : 'Unlock 1080p, 4K, and MP3 in one tap.'}
          </p>

          <ul className="mt-5 space-y-2.5 text-sm text-white/80">
            <Feature icon={<MonitorPlay className="h-4 w-4" />} text="1080p Full HD and 4K Ultra HD" />
            <Feature icon={<Music className="h-4 w-4" />} text="MP3 audio extraction" />
            <Feature icon={<Ban className="h-4 w-4" />} text="Remove banner advertisements" />
            <Feature icon={<Sparkles className="h-4 w-4" />} text="Priority conversion queue" />
          </ul>

          {done ? (
            <div className="mt-6 rounded-xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-center text-sm text-emerald-200">
              You’re on the list. We’ll send Premium access to {email.trim().toLowerCase()}.
            </div>
          ) : (
            <form onSubmit={submit} className="mt-6 space-y-3">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name (optional)"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm outline-none placeholder:text-white/30 focus:border-[#0a84ff]"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@icloud.com"
                required
                className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm outline-none placeholder:text-white/30 focus:border-[#0a84ff]"
              />
              {error && <p className="text-xs text-red-400">{error}</p>}
              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-amber-300 to-orange-500 py-2.5 text-sm font-semibold text-zinc-900 shadow-lg disabled:opacity-60"
              >
                {loading ? 'Starting…' : 'Start Premium — $4.99/mo'}
              </button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  )
}

function Feature({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <li className="flex items-center gap-3">
      <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/8 text-amber-300">
        {icon}
      </span>
      <span>{text}</span>
      <Check className="ml-auto h-4 w-4 text-emerald-400" />
    </li>
  )
}
