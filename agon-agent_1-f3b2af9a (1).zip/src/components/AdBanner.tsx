type Props = {
  variant: 'leaderboard' | 'rectangle'
}

export default function AdBanner({ variant }: Props) {
  if (variant === 'leaderboard') {
    return (
      <div className="mx-auto mt-10 w-full max-w-[728px] px-3">
        <div className="glass-card flex h-[90px] items-center justify-center rounded-lg border border-dashed border-white/20 text-center">
          <div>
            <p className="text-[10px] uppercase tracking-[0.22em] text-white/35">Advertisement</p>
            <p className="mt-1 text-sm font-medium text-white/55">Your Ad Here · 728 × 90</p>
            <p className="text-[11px] text-white/30">Leaderboard · MacTube Network</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="glass-card mx-auto flex h-[250px] w-full max-w-[300px] items-center justify-center rounded-xl border border-dashed border-white/15 text-center">
      <div>
        <p className="text-[10px] uppercase tracking-[0.22em] text-white/35">Advertisement</p>
        <p className="mt-1 text-sm font-medium text-white/55">Sponsored Slot</p>
        <p className="text-[11px] text-white/30">300 × 250 Medium Rectangle</p>
      </div>
    </div>
  )
}
