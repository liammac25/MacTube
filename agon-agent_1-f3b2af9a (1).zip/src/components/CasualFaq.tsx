import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

const FAQS = [
  {
    q: 'Do I need an account?',
    a: 'Nope. Paste a link and convert. Recents stay on this MacTube window so you can jump back to something you already saved.',
  },
  {
    q: 'What can I download for free?',
    a: '360p, 480p, and 720p. That’s plenty for phones, group chats, and most everyday watching. 1080p, 4K, and MP3 need Premium.',
  },
  {
    q: 'Will this work on my phone?',
    a: 'Yes. The layout is built for phones and laptops. Use the same paste-and-convert flow you would on a Mac.',
  },
  {
    q: 'Is my link private?',
    a: 'We only store the public video info needed to convert — title, thumbnail, and the URL you pasted. We never ask for your passwords.',
  },
]

export default function CasualFaq() {
  const [open, setOpen] = useState<number | null>(0)

  return (
    <section className="mx-auto mt-10 mb-4 w-full max-w-2xl">
      <h2 className="text-center text-xl font-semibold tracking-tight">Questions, answered simply</h2>
      <div className="mt-4 space-y-2">
        {FAQS.map((item, i) => {
          const isOpen = open === i
          return (
            <div key={item.q} className="glass-card overflow-hidden rounded-2xl">
              <button
                type="button"
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
              >
                <span className="text-sm font-medium">{item.q}</span>
                <ChevronDown className={`h-4 w-4 shrink-0 text-white/40 transition ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              {isOpen && <p className="px-4 pb-4 text-[13px] leading-relaxed text-white/50">{item.a}</p>}
            </div>
          )
        })}
      </div>
    </section>
  )
}
